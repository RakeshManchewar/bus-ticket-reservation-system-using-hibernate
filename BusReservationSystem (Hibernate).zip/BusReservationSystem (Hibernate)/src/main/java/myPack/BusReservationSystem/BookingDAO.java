package myPack.BusReservationSystem;

import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.List;

public class BookingDAO 
{
    public void saveBooking(Booking booking) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();
            session.save(booking);
            tx.commit();
        }
    }

    public Booking getBooking(int id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Booking.class, id);
        }
    }

    public List<Booking> getAllBookings() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("from Booking", Booking.class).list();
        }
    }

    public void updateBooking(Booking booking) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();
            session.update(booking);
            tx.commit();
        }
    }

    public void deleteBooking(int id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();
            Booking booking = session.get(Booking.class, id);
            if (booking != null) session.delete(booking);
            tx.commit();
        }
    }
}