package myPack.BusReservationSystem;

import java.util.List;
import java.util.Scanner;

//======= Admin Methods =======
public class AdminMethods 
{
    public static void addBus() 
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Bus Name: ");
        String busName = sc.nextLine();

        System.out.print("Enter Source: ");
        String source = sc.nextLine();

        System.out.print("Enter Destination: ");
        String destination = sc.nextLine();

        System.out.print("Enter Total Seats: ");
        int totalSeats = sc.nextInt();

        // For new bus, available seats = total seats
        int availableSeats = totalSeats;

        Bus bus = new Bus();
        bus.setBusName(busName);
        bus.setSource(source);
        bus.setDestination(destination);
        bus.setTotalSeats(totalSeats);
        bus.setAvailableSeats(availableSeats);

        BusDAO busDAO = new BusDAO();
        boolean success = busDAO.saveBus(bus);

        if (success) 
        {
            System.out.println("Bus added successfully!");
        } 
        else 
        {
            System.out.println("Failed to add bus.");
        }
    }

    public static void viewAllBuses() 
    {
        BusDAO busDAO = new BusDAO();
        List<Bus> buses = busDAO.getAllBuses();

        System.out.println("\n--- List of Available Buses ---");
        System.out.printf("%-10s %-20s %-15s %-15s %-12s %-15s\n",
                "Bus ID", "Bus Name", "Source", "Destination", "Total Seats", "Available Seats");

        for (Bus bus : buses) 
        {
            System.out.printf("%-10d %-20s %-15s %-15s %-12d %-15d\n",
                    bus.getBusId(), bus.getBusName(), bus.getSource(),
                    bus.getDestination(), bus.getTotalSeats(), bus.getAvailableSeats());
        }
    }
}