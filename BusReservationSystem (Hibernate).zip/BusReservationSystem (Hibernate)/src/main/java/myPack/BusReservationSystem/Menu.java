package myPack.BusReservationSystem;

//======= Menu Display Methods =======
public class Menu 
{
  public static void showMainMenu() 
  {
      System.out.println("\n===== Welcome to Bus Reservation System =====");
      System.out.println("1. Admin Login");
      System.out.println("2. User Login");
      System.out.println("3. User Registration");
      System.out.println("0. Exit");
  }

  public static void showAdminMenu() 
  {
      System.out.println("\n--- Admin Menu ---");
      System.out.println("1. Add Bus");
      System.out.println("2. View All Buses");
      System.out.println("3. Check Seat Availability");
      System.out.println("4. Update Seat Count");
      System.out.println("0. Logout");
  }

  public static void showUserMenu() 
  {
      System.out.println("\n--- User Menu ---");
      System.out.println("1. Search Buses");
      System.out.println("2. Book Ticket");
      System.out.println("3. Cancel Booking");
      System.out.println("4. View Booking Details");
      System.out.println("5. Check Seat Availability");
      System.out.println("0. Logout");
  }
}
