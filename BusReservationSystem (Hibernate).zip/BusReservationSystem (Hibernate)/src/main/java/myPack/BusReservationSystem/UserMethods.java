package myPack.BusReservationSystem;

import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.List;
import java.util.Scanner;

//======= User Methods =======
public class UserMethods 
{
    public static void searchBusesByRoute() 
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter source: ");
        String source = sc.nextLine().trim();

        System.out.print("Enter destination: ");
        String destination = sc.nextLine().trim();

        try (Session session = HibernateUtil.getSessionFactory().openSession()) 
        {
            List<Bus> buses = session.createQuery(
                "FROM Bus WHERE source = :source AND destination = :destination", Bus.class)
                .setParameter("source", source)
                .setParameter("destination", destination)
                .list();

            if (buses.isEmpty()) 
            {
                System.out.println("No buses found for the given route.");
                return;
            }

            System.out.println("\nAvailable Buses:");
            System.out.printf("%-10s %-20s %-15s %-15s %-12s %-15s\n",
                "Bus ID", "Bus Name", "Source", "Destination", "Total Seats", "Available Seats");

            for (Bus bus : buses) 
            {
                System.out.printf("%-10d %-20s %-15s %-15s %-12d %-15d\n",
                    bus.getBusId(), bus.getBusName(), bus.getSource(), bus.getDestination(),
                    bus.getTotalSeats(), bus.getAvailableSeats());
            }
        }
    }

    public static void bookTicket(String username) 
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Bus ID to book: ");
        int busId = sc.nextInt();
        sc.nextLine(); // consume newline

        System.out.print("Enter your name: ");
        String passengerName = sc.nextLine();

        System.out.print("Enter number of seats to book: ");
        int seatsToBook = sc.nextInt();

        try (Session session = HibernateUtil.getSessionFactory().openSession()) 
        {
            Transaction tx = session.beginTransaction();

            Bus bus = session.get(Bus.class, busId);
            if (bus == null) 
            {
                System.out.println("❌ Invalid Bus ID. Booking failed.");
                return;
            }

            if (bus.getAvailableSeats() < seatsToBook) 
            {
                System.out.println("⚠ Only " + bus.getAvailableSeats() + " seats available. Booking failed.");
                return;
            }

            // Update bus seat count
            bus.setAvailableSeats(bus.getAvailableSeats() - seatsToBook);
            session.update(bus);

            // Create and save booking
            Booking booking = new Booking();
            booking.setBus(bus);
            booking.setPassengerName(passengerName);
            booking.setSeatsBooked(seatsToBook);
            booking.setBookingDateTime(java.time.LocalDateTime.now());

            session.save(booking);

            tx.commit();
            System.out.println("✅ Booking successful!");
            System.out.println("🧾 Your Booking ID is: " + booking.getBookingId());
        }
    }

    public static void cancelBooking() 
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter your Booking ID to cancel: ");
        int bookingId = sc.nextInt();

        try (Session session = HibernateUtil.getSessionFactory().openSession()) 
        {
            Transaction tx = session.beginTransaction();

            Booking booking = session.get(Booking.class, bookingId);
            if (booking == null) 
            {
                System.out.println("❌ Booking not found.");
                return;
            }

            Bus bus = booking.getBus();
            bus.setAvailableSeats(bus.getAvailableSeats() + booking.getSeatsBooked());
            session.update(bus);

            session.delete(booking);
            tx.commit();

            System.out.println("✅ Booking canceled successfully.");
        }
    }

    public static void viewBookingDetails(int bookingId) 
    {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) 
        {
            Booking booking = session.get(Booking.class, bookingId);

            if (booking == null) 
            {
                System.out.println("❌ No booking found with this ID.");
                return;
            }

            Bus bus = booking.getBus();
            System.out.println("\nBooking Details:");
            System.out.printf("%-12s %-20s %-15s %-20s %-15s %-15s\n", 
                "Booking ID", "Passenger Name", "Seats", "Bus Name", "Source", "Destination");

            System.out.printf("%-12d %-20s %-15d %-20s %-15s %-15s\n", 
                booking.getBookingId(), booking.getPassengerName(), booking.getSeatsBooked(),
                bus.getBusName(), bus.getSource(), bus.getDestination());
        }
    }
}