package myPack.BusReservationSystem;

import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class HibernateUtil 
{
	private static final SessionFactory sessionFactory;
	
	static 
	{
		try 
		{
			// Load configuration and build service registry
			StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
					.configure("hibernate.cfg.xml") // configures from hibernate.cfg.xml
					.build();
			
			// Build metadata from registry
			Metadata metadata = new MetadataSources(registry).getMetadataBuilder().build();
			
			// Build session factory from metadata
			sessionFactory = metadata.getSessionFactoryBuilder().build();
		}
		catch(Throwable ex)
		{
			System.err.println("SessionFactory creation failed: " + ex);
            throw new ExceptionInInitializerError(ex);
		}
	}
	
	public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }
}
