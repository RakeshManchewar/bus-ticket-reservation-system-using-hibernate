package myPack.BusReservationSystem;

import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.List;

public class BusDAO 
{
    public boolean saveBus(Bus bus) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.save(bus);
            tx.commit();
            return true;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            System.out.println("Error saving bus: " + e.getMessage());
            return false;
        }
    }

    public Bus getBus(int id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Bus.class, id);
        }
    }

    public List<Bus> getAllBuses() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("from Bus", Bus.class).list();
        }
    }

    public List<Bus> getBusesByRoute(String source, String destination) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("from Bus where source = :source and destination = :destination", Bus.class)
                          .setParameter("source", source)
                          .setParameter("destination", destination)
                          .list();
        }
    }

    public boolean updateBus(Bus bus) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.update(bus);
            tx.commit();
            return true;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            System.out.println("Error updating bus: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteBus(int id) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Bus bus = session.get(Bus.class, id);
            if (bus == null) return false;

            tx = session.beginTransaction();
            session.delete(bus);
            tx.commit();
            return true;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            System.out.println("Error deleting bus: " + e.getMessage());
            return false;
        }
    }
}