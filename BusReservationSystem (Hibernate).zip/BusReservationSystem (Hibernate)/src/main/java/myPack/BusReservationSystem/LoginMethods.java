package myPack.BusReservationSystem;

import java.util.Scanner;

//======= Login Methods =======
public class LoginMethods 
{
    // ======= Admin Login =======
    public static boolean adminLogin() 
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter admin username: ");
        String username = sc.nextLine();

        System.out.print("Enter admin password: ");
        String password = sc.nextLine();

        AdminDAO adminDAO = new AdminDAO();
        Admin admin = adminDAO.getAdminByUsernameAndPassword(username, password);

        if (admin != null) 
        {
            System.out.println("Admin Login successful.");
            return true;
        } 
        else 
        {
            System.out.println("Invalid username or password.");
            return false;
        }
    }

    // ======= User Login =======
    public static String userLogin() 
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter username: ");
        String username = sc.nextLine();

        System.out.print("Enter password: ");
        String password = sc.nextLine();

        UserDAO userDAO = new UserDAO();
        User user = userDAO.getUserByUsernameAndPassword(username, password);

        if (user != null) 
        {
            System.out.println("Login successful. Welcome, " + username + "!");
            return username;
        } 
        else 
        {
            System.out.println("Invalid username or password.");
            return null;
        }
    }

    // ======= User Registration =======
    public static void registerUser() 
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Choose a username: ");
        String username = sc.nextLine();

        System.out.print("Choose a password: ");
        String password = sc.nextLine();

        UserDAO userDAO = new UserDAO();
        if (userDAO.getUserByUsername(username) != null) 
        {
            System.out.println("Username already taken. Try a different one.");
            return;
        }

        User newUser = new User();
        newUser.setUsername(username);
        newUser.setPassword(password);

        boolean isAdded = userDAO.addUser(newUser);
        if (isAdded) 
        {
            System.out.println("Registration successful! You can now log in.");
        }
    }
}