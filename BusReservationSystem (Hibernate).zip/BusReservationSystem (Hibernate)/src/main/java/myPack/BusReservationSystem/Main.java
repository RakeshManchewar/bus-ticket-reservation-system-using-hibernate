package myPack.BusReservationSystem;

import java.util.Scanner;

public class Main 
{
    public static void main(String[] args) 
    {
    	System.out.println( "Hello World!" );
    	
        Scanner sc = new Scanner(System.in);
        int mainChoice;

        do 
        {
            Menu.showMainMenu();
            System.out.print("Enter your choice: ");
            mainChoice = sc.nextInt();

            switch (mainChoice) 
            {
                case 1:
                    if (LoginMethods.adminLogin()) 
                    {
                        int adminChoice;
                        do 
                        {
                            Menu.showAdminMenu();
                            System.out.print("Enter your choice: ");
                            adminChoice = sc.nextInt();

                            switch (adminChoice) 
                            {
                                case 1:
                                    AdminMethods.addBus();
                                    break;
                                case 2:
                                    AdminMethods.viewAllBuses();
                                    break;
                                case 3:
                                    UtilityMethods.checkSeatAvailability();
                                    break;
                                case 4:
                                    UtilityMethods.updateSeatCount();
                                    break;
                                case 0:
                                    System.out.println("Logging out from Admin...");
                                    break;
                                default:
                                    System.out.println("Invalid choice. Try again.");
                            }
                        } while (adminChoice != 0);
                    }
                    break;

                case 2:
                    String username = LoginMethods.userLogin();
                    if (username != null)
                    {
                        int userChoice;
                        do 
                        {
                            Menu.showUserMenu();
                            System.out.print("Enter your choice: ");
                            userChoice = sc.nextInt();

                            switch (userChoice) 
                            {
                                case 1:
                                    UserMethods.searchBusesByRoute();
                                    break;
                                case 2:
                                    UserMethods.bookTicket(username);
                                    break;
                                case 3:
                                    UserMethods.cancelBooking();
                                    break;
                                case 4:
                                    System.out.print("Enter your Booking ID to view details: ");
                                    int bookingId = sc.nextInt();
                                    UserMethods.viewBookingDetails(bookingId);
                                    break;
                                case 5:
                                    UtilityMethods.checkSeatAvailability();
                                    break;
                                case 0:
                                    System.out.println("Logging out from User...");
                                    break;
                                default:
                                    System.out.println("Invalid choice. Try again.");
                            }
                        } while (userChoice != 0);
                    }
                    break;

                case 3:
                    LoginMethods.registerUser();
                    break;

                case 0:
                    System.out.println("Exiting system. Thank you!");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }

        } while (mainChoice != 0);

        sc.close();
    }
}