package myPack.BusReservationSystem;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

//======= Utility Methods =======
public class UtilityMethods 
{
    public static void checkSeatAvailability() 
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Bus ID to check seat availability: ");
        int busId = sc.nextInt();

        try (Session session = HibernateUtil.getSessionFactory().openSession()) 
        {
            Bus bus = session.get(Bus.class, busId);

            if (bus != null) 
            {
                System.out.println("Bus Name: " + bus.getBusName());
                System.out.println("Available Seats: " + bus.getAvailableSeats());
            } 
            else 
            {
                System.out.println("No bus found with ID: " + busId);
            }
        }
    }

    public static void updateSeatCount() 
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Bus ID to update: ");
        int busId = sc.nextInt();

        try (Session session = HibernateUtil.getSessionFactory().openSession()) 
        {
            Bus bus = session.get(Bus.class, busId);

            if (bus == null) 
            {
                System.out.println("No bus found with ID: " + busId);
                return;
            }

            System.out.print("What do you want to update?\n1. Total Seats\n2. Available Seats\nChoose option: ");
            int choice = sc.nextInt();

            Transaction tx = session.beginTransaction();

            if (choice == 1) 
            {
                System.out.print("Enter new total seats: ");
                int totalSeats = sc.nextInt();
                bus.setTotalSeats(totalSeats);
            } 
            else if (choice == 2) 
            {
                System.out.print("Enter new available seats: ");
                int availableSeats = sc.nextInt();
                bus.setAvailableSeats(availableSeats);
            } 
            else 
            {
                System.out.println("Invalid choice.");
                return;
            }

            session.update(bus);
            tx.commit();
            System.out.println("Seat count updated successfully.");
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
    }
}