package myPack.BusReservationSystem;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

public class AdminDAO 
{
	public void saveAdmin(Admin admin) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            session.beginTransaction();
            session.save(admin);
            session.getTransaction().commit();
        }
    }

    public Admin getAdmin(String username) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Admin.class, username);
        }
    }

    public Admin getAdminByUsernameAndPassword(String username, String password) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Admin> query = session.createQuery(
                "FROM Admin WHERE username = :uname AND password = :pwd", Admin.class);
            query.setParameter("uname", username);
            query.setParameter("pwd", password);
            return query.uniqueResult();  // returns null if not found
        }
    }

    public List<Admin> getAllAdmins() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("from Admin", Admin.class).list();
        }
    }

    public void updateAdmin(Admin admin) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();
            session.update(admin);
            tx.commit();
        }
    }

    public void deleteAdmin(String username) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();
            Admin admin = session.get(Admin.class, username);
            if (admin != null) session.delete(admin);
            tx.commit();
        }
    }
}